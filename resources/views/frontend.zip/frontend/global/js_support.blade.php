<script src="{{ asset('frontend/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('frontend/js/jquery-3.6.4.min.js') }}"></script>
<script src="{{ asset('frontend/js/scripts.js') }}"></script>
<script src="{{ asset('frontend/js/chart.min.js') }}"></script>
<script src="{{ asset('frontend/js/datatables.min.js') }}"></script>
<script src="{{ asset('frontend/js/datatables-simple-demo.js') }}"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"/>
